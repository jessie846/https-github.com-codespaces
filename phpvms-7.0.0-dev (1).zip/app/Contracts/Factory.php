<?php

namespace App\Contracts;

use Illuminate\Database\Eloquent\Factories\Factory as EloquentFactory;

abstract class Factory extends EloquentFactory
{
}
