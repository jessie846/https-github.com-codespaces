<?php

namespace App\Contracts;

/**
 * Class Service
 */
abstract class Service
{
}
