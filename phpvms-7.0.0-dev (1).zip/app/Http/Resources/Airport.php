<?php

namespace App\Http\Resources;

use App\Contracts\Resource;

class Airport extends Resource
{
}
