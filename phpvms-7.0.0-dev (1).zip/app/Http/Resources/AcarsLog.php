<?php

namespace App\Http\Resources;

use App\Contracts\Resource;

/**
 * ACARS table but only include the fields for the routes
 * Class AcarsRoute
 */
class AcarsLog extends Resource
{
}
