<?php

namespace App\Models;

use Laratrust\Models\Permission as LaratrustPermission;

/**
 * @method static firstOrCreate(array $array, array $array1)
 */
class Permission extends LaratrustPermission
{
}
