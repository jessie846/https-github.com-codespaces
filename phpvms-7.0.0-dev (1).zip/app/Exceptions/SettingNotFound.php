<?php

namespace App\Exceptions;

use Exception;

class SettingNotFound extends Exception
{
}
